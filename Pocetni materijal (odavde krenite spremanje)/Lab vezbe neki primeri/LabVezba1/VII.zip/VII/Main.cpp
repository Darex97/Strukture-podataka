#include "BigNumSorter.h"
#include<iostream>
using namespace std;
void main()
{
	BigNumSorter N(5,3);
	int a[]={1,1,2,3,1};
	int b[]={1,3,2,0};
	int c[]={2,0,0,0};
	N.Dodaj(a,5);
	N.Dodaj(b,4);
	N.Dodaj(c,4);
	N.Sort();
	N.Stampaj();




}