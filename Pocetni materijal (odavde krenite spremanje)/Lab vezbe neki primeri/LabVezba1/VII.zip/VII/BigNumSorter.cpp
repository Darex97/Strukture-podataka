#include <iostream>
using namespace std;
#include "BigNumSorter.h"
BigNumSorter::BigNumSorter(int nn, int mm)
{ 
	zauzeto = 0;
	this->m = mm;
	this->n = nn;
	mat = new int*[m];
	for(int i=0; i<m; i++)
		mat[i] = new int[n];
	for(int i=0; i<m; i++)
		for(int j=0; j<n; j++)
			mat[i][j]=0;

}
void BigNumSorter::Dodaj(int* broj, int n )
{
	int j=n-1;
	if(zauzeto < m && n <= this->n)
	{
	for(int i=n-1-(this->n - n); i>=0; i--)
	{
		mat[zauzeto][j--] = broj[i];
	}
	}
	zauzeto++;
}
void BigNumSorter::Sort()
{
	for(int i=n-1; i>=0; i-- )
	{
		for(int k=0; k<m-1; k++)
			for(int p = k+1; p < m; p++)
				if(mat[k][i]<mat[p][i])
				{
					for(int y=0; y<n; y++)
					{
						int pom = mat[k][y];
						mat[k][y] = mat[p][y];
						mat[p][y] = pom;
					}
					

				}
	}
}
void BigNumSorter::Stampaj()
{
	for(int i=0; i<m; i++ )
	{
		for(int j=0; j<n; j++)
		{
			cout<<mat[i][j]<<" ";
		}
		cout<<endl;
	}


}