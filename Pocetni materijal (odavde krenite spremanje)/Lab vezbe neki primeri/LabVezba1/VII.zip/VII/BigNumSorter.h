class BigNumSorter
{
public:
	int n;
	int m;
	int** mat;
	int zauzeto;
	BigNumSorter( int, int);
	void Dodaj(int*,int);
	void Sort();
	void Stampaj();
};