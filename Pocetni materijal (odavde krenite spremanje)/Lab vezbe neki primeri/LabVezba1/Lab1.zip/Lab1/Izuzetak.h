class Izuzetak
{
public:
	char* poruka;
	Izuzetak(char*);
	void Stampaj();
};