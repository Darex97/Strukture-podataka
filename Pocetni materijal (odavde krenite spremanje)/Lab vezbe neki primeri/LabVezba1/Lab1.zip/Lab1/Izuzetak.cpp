#include <string.h>
#include <iostream>
using namespace std;
#include "Izuzetak.h"
Izuzetak::Izuzetak(char* por)
{
	this->poruka = new char[strlen(por)+1];
	strcpy(poruka, por);
}
void Izuzetak::Stampaj()
{
	cout<<poruka;
}