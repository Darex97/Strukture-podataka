class CPolynom
{
public:
	int order;
	double* koef;
public:
	CPolynom(int);
	CPolynom& operator=(CPolynom&);
	void Coefs(int* exp, double* coef, int no);/* Metod za dodavanje polja koeficijenata. 
	Exp* sadrzi eksponente clanova polinoma ciji su odgovarajuci koeficijenti dati u polju coefs*. 
	Vrednost promenljive no je duzina polja exp* i coefs* */
	void Sub(CPolynom poly1, CPolynom poly2); /*Metod za oduzimanje 2 polinoma i dodelu vrednosti razlike polinomu nad kojim se poziva ovaj metod*/
	void Add(CPolynom poly1, CPolynom poly2);/*Metod za sabiranje dva polinoma*/
	void Print();/* Metod za stampanje polinoma*/
	void Mul(CPolynom, CPolynom); /*Metod za mnozenje dva polinoma i dodelu vrednosti proizvoda polinomu nad kojim se poziva ovaj metod*/
	void Coef(int,double);/*Metod za dodavanje odredjenog koeficijenta*/
	void Div(CPolynom, CPolynom);/*Metod za deljenje polinoma*/
	void Izvod();/*nalazenje izvoda polinoma*/
	void NIzvod(int n);/*nalazenje n-tog izvoda polinoma*/
};