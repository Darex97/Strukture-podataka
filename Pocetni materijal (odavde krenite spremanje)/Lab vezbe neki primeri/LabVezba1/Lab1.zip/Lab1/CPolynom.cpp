#include "Izuzetak.h"
#include <iostream>
using namespace std;
#include "CPolynom.h"
CPolynom::CPolynom(int o)
{
	this->order = o;
	koef = new double[order+1];
	for(int i=0; i<=order; i++)
		koef[i] = 0;
}
void CPolynom::Coefs(int* expo, double* coefs, int noo)
{
	for(int i=0; i<noo; i++)
		this->koef[expo[i]] = coefs[i]; 
}
void CPolynom::Add(CPolynom poly1, CPolynom poly2)
{
	if(this->order >= poly1.order && this->order >= poly2.order)
	{
		int maxord = (poly1.order>poly2.order ? poly1.order : poly2.order);
		for(int i=0; i<=maxord; i++)
		{
			if(poly1.order >= i && poly2.order>= i)
				this->koef[i] = poly1.koef[i] + poly2.koef[i];
			else
			{
				if(poly1.order >= i)
					this->koef[i] = poly1.koef[i];
				else
					this->koef[i] = poly2.koef[i];
			}

		}

	}
	else
		throw Izuzetak("Greska pri sabiranju!");
}
void CPolynom::Sub(CPolynom poly1, CPolynom poly2)
{
	if(this->order >= poly1.order && this->order >= poly2.order)
	{
		int maxord = (poly1.order < poly2.order ? poly2.order : poly1.order);
		for(int i=0; i<=maxord; i++)
		{
		if(poly1.order >= i && poly2.order >= i)
		{
			this->koef[i] = poly1.koef[i] - poly2.koef[i];
		}
		else
		{
		if(poly1.order >= i)
		{
			this->koef[i] = poly1.koef[i];
		}
		else
			this->koef[i] = -poly2.koef[i];
		}
		}
	}
}
void CPolynom:: Print()
{
	for(int i=order; i>0; i--)
	{
		if(koef[i]>0)
			cout<<"+"<<this->koef[i]<<"X^"<<i;
		if(koef[i]<0)
			cout<<this->koef[i]<<"X^"<<i;
	}
		if(koef[0]>0)
			cout<<"+"<<koef[0];
		if(koef[0]<0)
			cout<<koef[0];
		cout<<endl;
	
}
void CPolynom::Mul(CPolynom poly1, CPolynom poly2)
{
	if(order>= poly1.order + poly2.order)
	{
		
		for(int i=0; i<=order; i++)
			this->koef[i]=0;

		for(int i=0; i<=poly1.order; i++)
			for(int j = 0; j<=poly2.order; j++)
			{
				this->koef[i+j] += poly1.koef[i]*poly2.koef[j];
			}
	}
	else throw(Izuzetak("Velicina rezultantnog polinoma nije odgovarajuca!"));
}
CPolynom& CPolynom:: operator=(CPolynom& orig)
{
	if(this!=&orig)
	{
		delete [] this->koef;
		this->order = orig.order;
		this->koef = new double[order];
		for(int i=0; i<=order; i++)
			this->koef[i] = orig.koef[i];
	}
	return *this;
}
void CPolynom::Coef(int exp, double value)
{
	this->koef[exp] = value;
}
/*void CPolynom::Div(CPolynom poly1, CPolynom poly2)
{
	if(this->order > poly1.order - poly2.order && poly1.order>=poly2.order )
	{
		for(int i=0; i<poly1.order; i++)
			for(int j=0; j<poly2.order; i++)
				
	}
}*/
void CPolynom::Izvod()
{
	if(order>0)
	{
		for(int i=1; i<=order; i++)
			this->koef[i-1] = koef[i]*i;
		order--;
	}
	else throw(Izuzetak("Greska pri nalazenju izvoda!"));
}
void CPolynom::NIzvod(int N)
{
	if(order >= N)
	{
		for(int i=0; i<N; i++)
			Izvod();
	}
	else
		throw (Izuzetak("Ne moze se naci trazeni izvod!"));
}