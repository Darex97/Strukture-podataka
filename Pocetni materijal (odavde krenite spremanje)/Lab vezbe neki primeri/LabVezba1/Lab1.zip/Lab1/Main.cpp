#include "Izuzetak.h"
#include <iostream>
using namespace std;
#include"CPolynom.h"
void main()
{
	int exp1[] = {0,1,2,3};
	double coef1[] = {5,2,3,2};
	CPolynom poly1(3);
	CPolynom poly2(2);
	CPolynom poly3(5);
	CPolynom poly4(1);
	try{
	poly1.Coefs(exp1,coef1,4);
	int exp2[] = {0,1,2};
	double coef2[] = {3,3,7};
	poly2.Coefs(exp2, coef2, 3);
	poly1.Print();
	/*poly1.NIzvod(1);*/
	poly1.Print();
	poly2.Print();
	poly3.Add(poly2, poly1);
	poly3.Print();
	poly3.Mul(poly2, poly1);
	poly4 = poly3;
	poly4.Print(); 
	poly3.Print();
	}
	catch(Izuzetak p)
	{
	p.Stampaj();
	}
	
}