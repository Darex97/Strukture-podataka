#pragma once

#include <iostream>

#include <stack>

using namespace std;

class MaxHeap
{
public:
	MaxHeap(int numberOfLevels);
	~MaxHeap();

	bool isEmpty() { return _currNumberOfElements == 0; }
	bool isFull() { return _currNumberOfElements == _maxNumberOfElements; }

	void insert(int element);
	void heapInsert(int element);

	void mix(MaxHeap& mh1, MaxHeap& mh2);
	void toMinHeap();

private:
	bool* _taken;
	int* _key;
	int* _left;
	int* _right;

	int _maxNumberOfElements;
	int _currNumberOfElements;
	int _numberOfLevels;

	void invertInsert(int element);
	void heapInvertInsert(int element);
	void _delete(int coef);

	int* toArray();
	int* toOrganizedArray();

	void reset();
};