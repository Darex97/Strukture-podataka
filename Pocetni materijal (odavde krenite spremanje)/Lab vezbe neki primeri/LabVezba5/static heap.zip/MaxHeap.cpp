#include "MaxHeap.h"



MaxHeap::MaxHeap(int numberOfLevels)
{
	if ( numberOfLevels > 0 )
	{
		int numberOfElemets = 2;

		if ( numberOfLevels != 1)
			for ( int i = 1; i < numberOfLevels; i++ )
				numberOfElemets *= 2;

		numberOfElemets--;

		_taken = new bool [numberOfElemets];
		_key = new int [numberOfElemets];
		_left = new int [numberOfElemets];
		_right = new int [numberOfElemets];

		_maxNumberOfElements = numberOfElemets;
		_currNumberOfElements = 0;
		_numberOfLevels = numberOfLevels;

		for ( int i = 0; i < _maxNumberOfElements; i++ )
		{
			_taken[i] = false;

			if ( i < ( ( ( numberOfElemets + 1) / 2 ) - 1 ) )
			{
				_left[i] = 2 * i + 1;
				_right[i] = 2 * i + 2;
			}
			else
			{
				_left[i] = -1;
				_right[i] = -1;
			}
		}
	}
	else
		throw new exception ("Binary tree must have at least one level");
}



MaxHeap::~MaxHeap()
{
	delete _taken;
	delete _key;
	delete _left;
	delete _right;
}



void MaxHeap::insert(int element)				//Radi na principu inserta u stablo
{												//U sustini se ne koristi nigde al sam ga lepo modifikovao pa ga ostavih
	if ( !isFull() )
	{
		int curr = 0;
		int prev = -1;

		int counter = 0;

		stack<int> _stack;

		while ( counter <= _numberOfLevels && curr != -1 && _taken[curr] != false )
		{
			prev = curr;

			if ( _key[prev] < element )
				curr = _right[curr];
			else
				curr = _left[curr];

			_stack.push(prev);

			counter++;
		}

		if ( counter > _numberOfLevels || curr == -1 )
			throw new exception ("Heap doesn't have enough levels to insert element");

		if ( _taken[0] == false )
		{
			_key[0] = element;
			_taken[0] = true;
		}
		else if ( _key[prev] < element )
		{
			_taken[_right[prev]] = true;
			_key[_right[prev]] = element;
			curr = _right[prev];
		}
		else
		{
			_taken[_left[prev]] = true;
			_key[_left[prev]] = element;
			curr = _left[prev];
		}

		_currNumberOfElements++;

		bool found = false;

		while ( !_stack.empty() && found != true )
		{
			prev = _stack.top();

			_stack.pop();

			if ( _key[prev] < _key[curr] )
			{
				int temp = _key[prev];
				_key[prev] = _key[curr];
				_key[curr] = temp;
			}
			else
				found = true;

			curr = prev;
		}
	}
	else
		throw new exception ("Tree already full, can't insert any more elements");
}



void MaxHeap::heapInsert(int element)
{
	if ( isFull() )
		throw new exception ("Tree already full, can't insert any more elements");

	int index = _currNumberOfElements;

	_taken[index] = true;

	while ( index > 0 && _key[((index+1)/2)-1] < element )
	{
		_key[index] = _key[((index+1)/2)-1];
		index = ((index+1)/2)-1;
	}

	_key[index] = element;

	_currNumberOfElements++;
}



void MaxHeap::mix(MaxHeap& mh1, MaxHeap& mh2)
{
	int* data1 = mh1.toArray();
	int size1 = mh1._currNumberOfElements;

	int* data2 = mh2.toArray();
	int size2 = mh2._currNumberOfElements;

	int size = size1 + size2;
	int* data = new int [size];

	if ( size > _maxNumberOfElements )
		throw new exception ("Heap too small to accept mix of heaps");

	for ( int i = 0; i < size1; i++ )
		data[i] = data1[i];
	for ( int i = size1; i < size1 + size2; i++ )
		data[i] = data2[i - size1];

	if ( !isEmpty() )
		reset();

	for ( int i = 0; i < size; i++ )
		heapInsert(data[i]);
}



void MaxHeap::toMinHeap()
{
	int* _data = toOrganizedArray();

	int size = _currNumberOfElements;

	reset();

	for ( int i = 0; i < size; i++ )
		heapInvertInsert(_data[size-1 - i]);
}

//PRIVATE FUNCTIONS

void MaxHeap::invertInsert(int element)			//Isto vazi kao i za obican isnert gore
{												
	if ( !isFull() )
	{
		int curr = 0;
		int prev = -1;

		int counter = 0;

		stack<int> _stack;

		while ( counter <= _numberOfLevels && _taken[curr] != false )
		{
			prev = curr;

			if ( _key[prev] < element )
				curr = _right[curr];
			else
				curr = _left[curr];

			_stack.push(prev);

			counter++;
		}

		if ( counter > _numberOfLevels )
			throw new exception ("Tree doesn't have enough levels to insert element");

		if ( _taken[0] == false )
		{
			_key[0] = element;
			_taken[0] = true;
		}
		else if ( _key[prev] < element )
		{
			_taken[_right[prev]] = true;
			_key[_right[prev]] = element;
			curr = _right[prev];
		}
		else
		{
			_taken[_left[prev]] = true;
			_key[_left[prev]] = element;
			curr = _left[prev];
		}

		_currNumberOfElements++;

		bool found = false;

		while ( !_stack.empty() && found != true )
		{
			prev = _stack.top();

			_stack.pop();

			if ( _key[prev] > _key[curr] )
			{
				int temp = _key[prev];
				_key[prev] = _key[curr];
				_key[curr] = temp;
			}
			else
				found = true;

			curr = prev;
		}
	}
	else
		throw new exception ("Tree already full, can't insert any more elements");
}												



void MaxHeap::heapInvertInsert(int element)
{
	if ( isFull() )
		throw new exception ("Tree already full, can't insert any more elements");

	int index = _currNumberOfElements;

	_taken[index] = true;

	while ( index > 0 && _key[((index+1)/2)-1] > element )
	{
		_key[index] = _key[((index+1)/2)-1];
		index = ((index+1)/2)-1;
	}

	_key[index] = element;
}



int* MaxHeap::toArray()
{
	int size = 0;

	for ( int i = 0; i < _maxNumberOfElements; i++ )
		if ( _taken[i] == true )
			size++;

	int* ret = new int [size];

	int counter = 0;

	for ( int i = 0; i < _maxNumberOfElements && counter < size; i++ )
		if ( _taken[i] == true )
			ret[counter++] = _key[i];

	return ret;
}



int* MaxHeap::toOrganizedArray()
{
	int* ret = toArray();

	int size = 0;

	for ( int i = 0; i < _maxNumberOfElements; i++ )
		if ( _taken[i] == true )
			size++;

	for ( int i = 0; i < size-1; i++ )
		for ( int j = i+1; j < size; j++)
			if ( ret[i] > ret[j] )
			{
				int temp = ret[i];
				ret[i] = ret[j];
				ret[j] = temp;
			}

	return ret;
}



void MaxHeap::reset()
{
	_currNumberOfElements = 0;
	
	for ( int i = 0; i < _maxNumberOfElements; _taken[i++] )
		;
}