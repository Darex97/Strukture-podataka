#include <iostream>

#include "MaxHeap.h"

using namespace std;

void main()
{
	try
	{
		MaxHeap MH(2);

		MH.heapInsert(4);
		MH.heapInsert(3);
		MH.heapInsert(7);

		MaxHeap mh(2);

		mh.heapInsert(2);
		mh.heapInsert(0);
		mh.heapInsert(1);

		MaxHeap mix(3);

		mix.mix(MH,mh);

		mix.toMinHeap();

		char end;
		cin >> end;
	}
	catch (exception* e)
	{
		cout << e->what();
	}
}