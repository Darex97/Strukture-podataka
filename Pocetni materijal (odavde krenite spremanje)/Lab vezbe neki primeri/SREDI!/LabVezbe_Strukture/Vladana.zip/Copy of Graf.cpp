#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>

struct Edge;
struct Node
{ 
	int info; 
	struct Node* next; 
	struct Edge* adj;
};

struct Edge
{ 
	Node* dest; 
	Edge* link;
};

typedef struct Node Cvor;
typedef struct Edge Poteg;


class MojGraf		
{

private:

	Cvor *graf;

public:

	MojGraf()
	{
		graf=NULL;

	};

	Cvor* FindNode(int x);
    Poteg* FindEdge(int a, int b);
    void InsNode(int x);
	void DelNode(int x);
    void InsEdge(int a,int b);
    void DelEdge(int a, int b);
	void PrintGraph();
	void Ponori();
};

void MojGraf::Ponori()
{
	printf("\n");
	Cvor *temp;
	temp = graf;
	while(temp != NULL)
	{
		if(temp->adj == NULL)
		{
			printf("Cvor %d je ponor.\n", temp->info);
		}
		temp = temp->next;
	}
}

Cvor* MojGraf::FindNode(int x)
{
/* Trazenje zadatog cvora node u grafu;
  NULL ako cvora nema, odnosno ukazuje na pronadjeni cvor */

  Cvor* ptr;
  ptr=graf;

  while (ptr != NULL && ptr->info != x)
     ptr = ptr->next;  

  return ptr;

}

Poteg* MojGraf::FindEdge(int a, int b)
{ 
/* Trazenje potega izmedju cvorova a i b;
  NULL ako potega nema, odnosno ukazuje na pronadjeni poteg */

 Cvor* loca;
 Cvor* locb;
 Poteg* sl = NULL;

 loca = FindNode(a);
 locb = FindNode(b);

 if ( loca!=NULL && locb!=NULL )
 {
    sl=loca->adj; 
	while ( sl!=NULL && sl->dest!=locb ) 
	   sl=sl->link; 
 }

 return sl;

}

void MojGraf::InsNode(int x)
{ 
	/*Ubacivanje cvora x u graf */

	Cvor* ptr;

	 ptr = FindNode(x);

	 if (ptr!=NULL) 
		 printf("\n Cvor vec postoji u grafu! \n");
	 else 
	 {
		ptr = new Cvor;
		ptr->next = graf;
	    graf = ptr;
    	ptr->info = x;
        ptr->adj = NULL;
	 }

}

void MojGraf::DelNode(int x)
{
	/* Brisanje zadatog cvora u grafu */

  Cvor* ptr;
  Cvor* prev;
 
 if ( graf == NULL )
	 printf("\n Brisanje je nemoguce - prazan graf! \n");
 else 
   if ( graf->info == x )
   {
	 ptr=graf;
     graf=graf->next;
     free(ptr);
   }
   else
   {
     ptr=graf->next;
   	 prev=graf;
     while ( ptr != NULL && ptr->info != x )
	 {
		prev=ptr;
        ptr = ptr->next;
	 }
     if ( ptr != NULL )
	 {
	    prev->next = ptr->next;
		free(ptr);
	 }
	 else 
		 printf("\n Brisanje je nemoguce - cvora nema u grafu! \n");
   }

}

void MojGraf::InsEdge(int a,int b)
{
	/* Ubacivanje potega izmedju (postojecih) cvorova a i b */

   Cvor* loca;
   Cvor* locb;
   Poteg* locp;

   locp = FindEdge(a, b);

   if ( locp != NULL )
	 printf("\n Poteg vec postoji u grafu! \n");
   else
   {
     loca = FindNode(a);
     locb = FindNode(b);      
     if ( loca == NULL || locb == NULL )     
         printf("\n Ubacivanje potega nemoguce - nema odgovarajucih cvorova! \n");
     else 
	 {
         locp = new Poteg;
         locp->dest=locb;
         locp->link=loca->adj;
         loca->adj=locp;
	 }
   }

 return;

}

void MojGraf::DelEdge(int a, int b)
{
	/*Brisanje potega izmedju cvorova a i b */
  Cvor* loca;
  Cvor* locb;
  Poteg* ptr;
  Poteg* prev;    

  loca = FindNode(a);
  locb = FindNode(b);      

  if ( loca == NULL || locb == NULL )
       printf("\n Brisanje potega nemoguce- ne postoji cvor u grafu! \n");
  else 
    	 if ( loca->adj==NULL )
		 {
               printf("\n Ne postoje potezi koji polaze od cvora ");
	           printf("%d", a);
		 }
	 else
	 {
          ptr=loca->adj;
          prev=NULL;

          while (ptr!=NULL && ptr->dest!=locb)  
		  {
		        prev=ptr;
		        ptr=ptr->link; 
		  }
	      if ( ptr!=NULL )
		  {
                if ( prev==NULL )
					loca->adj= ptr->link;
                else
					prev->link=ptr->link;
                delete ptr;
		  }
	      else
		  printf("\n Ne postoji takav poteg ");   	
	 }

}

void MojGraf::PrintGraph()
{ 
	/*Stampanje grafa */

    Poteg* sl;
    Cvor* odr;
    Cvor* pom;

    if ( graf == NULL )
        printf("\n Prazan graf! \n");
    else
	{
		pom=graf; 
        while ( pom != NULL )
		{
             sl= pom->adj;
             if ( sl == NULL )
			 { 
		           printf("\n Cvor ");
	               printf("%d",pom->info);
		           printf(" nema potege ");
			 }
	         else 
			 { 
	               printf("\n Cvor ");
	               printf("%d",pom->info);
	           	   printf(" ima potege do cvorova ");		 

		           while ( sl != NULL )
				   {
						odr = sl->dest;
                        printf("%d", odr->info);
						printf(" ");
						sl = sl->link;
				   }
				   
			 }

        pom=pom->next;

		}
	}



}



void Main()
{ 
  printf("\nFunkcije za rad sa grafom\n" );
  printf("\n1. Unosenje novog cvora");
  printf("\n2. Brisanje cvora");
  printf("\n3. Unosenje potega");
  printf("\n4. Brisanje potega");
  printf("\n5. Stampanje grafa");
  printf("\n6. Stampanje ponora");
  printf("\n7. Izlazak iz programa\n");
  printf("\nIzbor:");

}

void main()
{
  int unos;
  int cvora;
  int cvorb;
  int element;

  MojGraf mgraf;

  Main();
  scanf("%d",&unos);

  while ( unos >= 1 && unos < 7 )
  {
   switch (unos)
   {
		case 1:
		case 2:
				{
				    printf("\n Unesi cvor grafa: ");
					scanf("%d",&element);
					if ( unos == 1 ) 
						mgraf.InsNode(element);
					else
						mgraf.DelNode(element);		       
				}
					break;
		case 3:
		case 4:
				{
					printf("\n Unesi pocetni cvor potega ");
					scanf("%d", &cvora);

					printf("\n Unesi zavrsni cvor potega ");
					scanf("%d",&cvorb);
 
					if ( unos == 3 ) 
						mgraf.InsEdge(cvora, cvorb);
					else
						mgraf.DelEdge(cvora, cvorb);
				}
				break;
		case 5:
				 mgraf.PrintGraph();
				 break;
		case 6:
			     mgraf.Ponori();
				 break;
	}

   Main();
   scanf("%d",&unos);

  }
}
