//////////////////////////////////
// Milosevic Vladana 9698
#include<iostream.h>
#include<stdio.h>

// Cvor stabla
struct tag_cvor
{
	struct tag_cvor *left;
	struct tag_cvor *right;
	int info;
};
typedef tag_cvor TCvor;

// Klasa kojom je implementirano stablo
class CStablo
{
private:
	TCvor *root;
	int max;
	int tekSum;
public:
	CStablo();
	void Insert(int i);
	void Delete(int i);
	void Print();
	int Height();
private:
	void preorderPrint(TCvor* cvor);
	TCvor* dodaj(TCvor* cvor, int i);
	void preorderHeight(TCvor* cvor);
};

////////////////////////////////
// Implementacija stabla
CStablo::CStablo()
{
	root = NULL;
}

void CStablo::Insert(int i)
{
	root = dodaj(root, i);
}

void CStablo::Delete(int i)
{
	// Ovo nisam implementirala
	printf("\nOva funkcija nije implementirana!\n");
}

void CStablo::Print()
{
	// Stampam cvor u preorder redosledu
	printf("\nStablo u preorder redosledu:\n");
	preorderPrint(root);
}

int CStablo::Height()
{
	max = 0;
	tekSum = 0;
	preorderHeight(root);

	return max - 2;
}

TCvor* CStablo::dodaj(TCvor* cvor, int i)
{
	// Dodajem novi cvor
	if(cvor == NULL)
	{
		cvor = new TCvor;
		cvor->info = i;
		cvor->left = NULL;
		cvor->right = NULL;
	}
	else
	{
		if(i < cvor->info)
			cvor->left = dodaj(cvor->left, i);
		else
			cvor->right = dodaj(cvor->right, i);
	}

	return cvor;
}

void CStablo::preorderPrint(TCvor* cvor)
{
	// Stampanje u preorder redosledu
	if(cvor != NULL)
	{
		printf("%d\n", cvor->info);
		preorderPrint(cvor->left);
		preorderPrint(cvor->right);
	}
}

void CStablo::preorderHeight(TCvor* cvor)
{
	tekSum++;
	if(cvor != NULL)
	{   
		int sumTemp = tekSum;
		preorderHeight(cvor->left);
		tekSum = sumTemp;
		preorderHeight(cvor->right);
	}
	else
	{
		if(tekSum > max)
			max = tekSum;
		tekSum -= 1;    
	}
}

void Main()
{ 
  printf("\nFunkcije za rad sa stablom\n" );
  printf("\n1. Unosenje novog cvora");
  printf("\n2. Brisanje cvora");
  printf("\n3. Stampanje stabla");
  printf("\n4. Stampanje visine stabla");
  printf("\n5. Izlazak iz programa\n");
  printf("\nIzbor:");

}

void main()
{
  int unos;
  int element;
  CStablo stablo;

  Main();
  scanf("%d",&unos);

  while ( unos >= 1 && unos < 5 )
  {
   switch (unos)
   {
		case 1:
		case 2:
				{
				    printf("\n Unesi cvor stabla: ");
					scanf("%d",&element);
					if ( unos == 1 ) 
						stablo.Insert(element);
					else
						stablo.Delete(element);	       
				}
				break;
		case 3:
				 stablo.Print();
				 break;
		case 4:
			     printf("\nVisina stabla je: %d\n", stablo.Height());
				 break;
	}

   Main();
   scanf("%d",&unos);

  }
}
