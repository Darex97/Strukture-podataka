#include <iostream.h>
#include <string.h>

class CRasutaTablica
{
	int tab[50][2];
	char kw[50][20];

public:

	CRasutaTablica();
	void Add( char* rec );
	void Search( char* rec );
	void Print();
	int Fun( char* niz );

};

CRasutaTablica::CRasutaTablica()
{
	int i, j;
	 
	for( i = 0; i < 50; i++ )
		for( j = 0; j < 2; j++ )
			tab[i][j] = -1;

	for( i = 0; i < 50; i++ )
		strcpy(kw[i], "");

	strcpy( kw[0], "private");
	strcpy( kw[1], "public");
	strcpy( kw[2], "protected");
	strcpy( kw[3], "byte");
    strcpy( kw[4], "short");
	strcpy( kw[5], "int");
	strcpy( kw[6], "long");
	strcpy( kw[7], "float");
	strcpy( kw[8], "double");
    strcpy( kw[9], "char");
	strcpy( kw[10], "boolan");
	strcpy( kw[11], "if");
	strcpy( kw[12], "for");
	strcpy( kw[13], "while");
    strcpy( kw[14], "do");
	strcpy( kw[15], "break");
	strcpy( kw[16], "continue");
	strcpy( kw[17], "class");
	strcpy( kw[18], "extands");
    strcpy( kw[19], "static");
	strcpy( kw[20], "final");
	strcpy( kw[21], "void");
	strcpy( kw[22], "else");
	strcpy( kw[23], "return");
    strcpy( kw[24], "switch");
	strcpy( kw[25], "case");
	strcpy( kw[26], "interface");
	strcpy( kw[27], "abstract");
	strcpy( kw[28], "implements");
    strcpy( kw[29], "define");
}

void CRasutaTablica::Add( char* rec )
{
	int k = 0, as, pom, ap;

	while( strcmp( kw[k], rec ) != 0 && strcmp(kw[k], "") != 0 )
		k++;

	if( strcmp(kw[k], "") == 0 )
		cout<<"\nTakva rec nije sluzbena rec Jave!";
	else
	{
		ap = Fun( rec );
		
		if ( tab[ap][0] == -1 )
		{
			tab[ap][0] = k;
			tab[ap][1] = ap;
		}
		else
		{
			as = ( ap + 1 ) % 50;

			while( tab[as][0] != -1 )
			{
				as = ( as + 1 ) % 50;
			}

			tab[as][0] = k;
			tab[as][1] = as;

			pom = ap;
			while ( pom != tab[pom][1] )
			{
				pom = tab[pom][1];
			}

			tab[pom][1] = as;

		}
	}
}

int CRasutaTablica::Fun( char* niz )
{
	int ap;

	ap = niz[0] - 'a' + 1;

	return ap;
}

void CRasutaTablica::Print()
{
	int i, j;

	cout<<"\nRasuta tablica\n";
	cout<<"info\tlink\n";

	for( i = 0; i < 10; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}

	cin>>j;

	for( i = 10; i < 20; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
	for( i = 20; i < 30; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
	for( i = 30; i < 40; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
	for( i = 40; i < 50; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
	for( i = 0; i < 50; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
	for( i = 0; i < 50; i++ )
	{
		for( j = 0; j < 2; j++ )
			cout<<tab[i][j]<<"\t";

		cout<<"\n";
	}
	cin>>j;
//	cout<<"\nPomocni vektor stabla\n";

//	i = 0;

//	while( kw[i] != "" )
//		cout<<kw[i]<<"\n";

}

void CRasutaTablica::Search( char* rec )
{
	int ap, as;
	ap = Fun(rec);

	if( strcmp( kw[tab[ap][0]] , rec ) == 0 )
	{
		cout<<"\nTrazena rec"<<rec<<"se u ras.tab. nalazi na poz."<<ap;
		cout<<"a u pomocnom vektoru simbola na poz."<<tab[ap][0];
	}
	else
	{
		if( tab[ap][0] == -1 )
			cout<<"\nNema takvog elem. u tablici!";
		else
		{
			as = ( ap + 1 ) % 50;
			while( strcmp( kw[tab[as][0]] , rec ) != 0 )
			{
				as = ( as + 1 ) % 50;
			}
			cout<<"\nTrazena rec"<<rec<<"se u ras.tab. nalazi na poz."<<ap;
			cout<<"a u pomocnom vektoru simbola na poz."<<tab[ap][0];
		}
	}
}


void main()
{
	CRasutaTablica RT;
	int i = 1, izbor = 1;
	char rec[20];

	while( izbor != 4 )
	{
		cout<<"\nRasuta tablica\n";
		cout<<"1. Kreiranje rasute tablice\n";
		cout<<"2. Trazenje zadatog elementa\n";
		cout<<"3. Stampanje tablice i pomocnog vektora\n";
		cout<<"4. Izlaz\n";
		cout<<"Izbor:";
		cin>>izbor;


		switch( izbor )
		{
			case 1:{cout<<"\nUnesi rec koju unosis u ras. tab. za kraj unesi 0:";
				cin>>rec;
				while ( strcmp( rec, "0") != 0)
				{
					RT.Add( rec );
					cout<<"\nUnesi novu rec\n";
					cin>>rec;
				}
				break;
			}

			case 2:{
				cout<<"\nUnesi rec koju trazis";
				cin>>rec;
				RT.Search( rec );
				break;
			}

			case 3:{
				RT.Print();
				break;
			}

		default: cout<<"\nPogresan unos!";
		}
	}
}
