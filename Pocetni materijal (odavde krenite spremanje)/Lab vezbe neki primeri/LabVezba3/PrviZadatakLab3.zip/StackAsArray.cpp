#include "StackAsarray.h"
#include "QueueAsArray.h"
#include "Izuzetak.h"
#include <iostream>
using namespace std;
StackAsArray::StackAsArray(int N) : QueueAsArray(N)
{
	strcpy(tip,"stek!");
}
void StackAsArray::Push(int el)
{
	this->enqueue(el);
}
int StackAsArray::Pop()
{
	if(!isEmpty())
	{
		return this->red[--r];
	}
	else
		throw Izuzetak("Prazan ",tip);
}
int StackAsArray::topEl()
{
	return this->red[r-1];
}
void StackAsArray::printStack()
{
	while(!isEmpty())
		cout<<Pop()<<" ";
	cout<<endl;
}
StackAsArray::~StackAsArray()
{
}