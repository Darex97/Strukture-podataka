#pragma once
#include <string.h>
#include <iostream>
using namespace std;
class Izuzetak
{
public:
	char* Msg;
	Izuzetak(char* mess, char* tipp)
	{
		this->Msg = new char[strlen(mess) + strlen(tipp) + 2];
		strcpy(Msg,mess);
		strcat(Msg, tipp);
	}
	void Stampaj()
	{
		cout<<Msg<<endl;
	}
	~Izuzetak()
	{

	}
};