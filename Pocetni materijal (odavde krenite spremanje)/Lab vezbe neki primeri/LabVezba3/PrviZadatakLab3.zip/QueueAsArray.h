#pragma once
class QueueAsArray
{
public:
	char tip[10];
	int *red;
	int N;//veli�ina polja
	int f;//indeks elementa na pocetku reda
	int r;//indeks praznog mesta na kraju reda
	QueueAsArray(int);//
	virtual ~QueueAsArray();
	void enqueue(int);//
	int dequeue(void);//
	bool isFull();//
	bool isEmpty();//
	int size();// vra�a broj elemenata u redu
	int front();
	void printQueue();
};