
#include "QueueAsArray.h"
class StackAsArray : QueueAsArray
{
public:
	StackAsArray(int N);
	void Push(int el);
	int Pop();
	int getSize();
	int topEl();
	void printStack();
	~StackAsArray();
};