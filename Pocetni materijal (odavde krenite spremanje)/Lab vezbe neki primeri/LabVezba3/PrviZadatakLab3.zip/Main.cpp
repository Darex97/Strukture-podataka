#include "StackAsArray.h"
#include "QueueAsArray.h"
#include "Izuzetak.h"
#include <iostream>
using namespace std;
void main()
{
	try{
	QueueAsArray a(6);
	a.enqueue(1);
	a.enqueue(2);
	a.enqueue(3);
	a.enqueue(4);
	cout<<a.dequeue()<<" ";
	cout<<a.dequeue()<<" ";
	cout<<a.dequeue()<<" ";
	cout<<a.dequeue()<<" ";
	cout<<endl;
	cout<<a.size()<<endl;//stampa broj elemenata u redu
	StackAsArray b(6);
	b.Push(1);
	b.Push(2);
	b.Push(3);
	b.Push(4);
	cout<<b.topEl()<<" ";
	cout<<b.Pop()<<" ";
	cout<<b.Pop()<<" ";
	cout<<b.Pop()<<" ";
	cout<<b.Pop()<<" ";
	cout<<b.Pop()<<" ";
	b.printStack();
	}
	catch(Izuzetak& e)
	{
		e.Stampaj();
	}
}
