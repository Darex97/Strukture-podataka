#include "QueueAsArray.h"
#include "Izuzetak.h"
QueueAsArray::QueueAsArray(int N)
{
	this->N = N;
	this->red = new int[N];
	f = 0;
	r = 0;
	strcpy(tip, "red!");
}
QueueAsArray::~QueueAsArray()
{
	delete [] red;
}
bool QueueAsArray::isEmpty()
{
	return r==f;
}
bool QueueAsArray::isFull()
{
	return(f == (r+1) % N);
}
void QueueAsArray::enqueue(int el)
{
	if(!isFull())
	{
	red[r] = el;
	r = (r+1) % N;
	}
	else
		throw Izuzetak("Pun ",tip);
}
int QueueAsArray::dequeue()
{
	if(!isEmpty())
	{
	int el = this->red[f];
	f = (f+1) % N;
	return el;
	}
	else
		throw Izuzetak("Prazan ",tip);
}
int QueueAsArray::size()
{
	return ((N-f+r) % N);
}
int QueueAsArray::front()
{
	if(!isEmpty())
		return red[f];
	else
		throw Izuzetak("Prazan ",tip);
}
void QueueAsArray::printQueue()
{
	for(int i = f; i!=r; i = (i+1)%N)
	{
		cout<<this->red[i]<<" ";
	}
	cout<<endl;
}